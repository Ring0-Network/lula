LULA I editable manuscript and analytical cache illustration.

Build: pdflatex -interaction=nonstopmode -halt-on-error LULA-I.tex;
bibtex LULA-I; then pdflatex twice. Requires llncs/splncs04, CM-Super,
algorithm2e, TikZ, placeins, booktabs and hyperref. Both figures are vector TikZ.
The author contact is intentional. No machine inventory, telemetry, private
research notes, benchmark logs, keys or cache files are included.

Optional: python -I -B cache_memory_tradeoff.py (mpmath1.3.0) reproduces
the analytical height illustration. It creates no signatures or measurements.
Its figures are FORS component-model exponents, not full-security guarantees.
The evaluated construction's complete reference-signer bound remains open.
